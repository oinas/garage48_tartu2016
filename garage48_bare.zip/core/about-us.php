<?php

$HTML[] = <<<EOF
<h1>About us</h1>
Some random text here!
EOF;
