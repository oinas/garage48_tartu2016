<?php

$HTML[] = <<<EOF
				</div>
			</div>
	
			<div class="footer">
				BringMyStuff &copy; 2016 | Team of ..., ..., ..., ... | Event SSC@Tartu - <a href="http://garage48.org/events/student-startup-camp-tartu-2016">Garage48 Student Startup Camp Tartu 2016</a>
			</div>
		</div>
	</body>
</html>
EOF;
